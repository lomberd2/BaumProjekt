public interface Node {
    public double getValue();
}
